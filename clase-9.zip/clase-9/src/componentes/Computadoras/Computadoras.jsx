import React from 'react'

const Computadoras = () => {
  return (
    <div>
        <h2>Sección Computadoras!!</h2>
        <h3>Compra la tuya!!</h3>
    </div>
  )
}

export default Computadoras