import React from 'react'

const Celulares = () => {
  return (
    <div>
        <h2>Sección Celulares</h2>
        <h3>Llevate tu Nokia 1100!!</h3>
    </div>
  )
}

export default Celulares