import React from 'react'

const Home = () => {
  return (
    <div>
        <h2>Bienvenidos a CellShop</h2>
        <h2>Tu Tienda de Electronica en Ciudad del Este</h2>
    </div>
  )
}

export default Home