import { useParams } from "react-router-dom"
//Vamos a utilizar un Hook para trabajar con ese parámetro dinámico. Este hook se llama "useParams". 

//ejemplo: https://cellshop.com/sillas/10
//con UseParams yo puedo obtener ese "10" y almacenarlo. 


const Sillas = () => {
    const {id} = useParams();
    //Obtengo el valor del parámetro y lo voy a desestructurar así puedo trabajar más cómodo con el dato. 
    console.log(id);
  return (
    <div>
        <h2>Sillas Gamer</h2>
        <p>ID Producto: {id} </p>
        <h3>Mejor comprate una de oficina que son más cómodas y baratas</h3>
    </div>
  )
}

export default Sillas